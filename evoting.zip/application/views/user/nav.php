
	<head>
		<title>Home</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
			<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/asset/css/main.css">
						    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" type="text/css">

								
	</head>
	<body>

		

		
		 <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center text-primary">
              <i class="fa fa-compass"></i>Petunjuk Penggunaan Program</h1>
          </div>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p class="text-justify">
			<?php echo $nav; ?>
			</p>
          </div>
        </div>
      </div>
    </div>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <a class="btn btn-block btn-danger btn-lg" href="javascript:window.history.back();">Kembali <i class="fa fa-arrow-left"></i></a>
          </div>
          <div class="col-md-9"></div>
        </div>
      </div>
    </div>
		
		
			</div>
			


	</body>
</html>

